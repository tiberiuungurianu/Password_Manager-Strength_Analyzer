using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace draft1_cw2.Views.Shared
{
    public class _TitleComponentModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
