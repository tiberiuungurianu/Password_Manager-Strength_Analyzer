using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace draft1_cw2.Views.Home
{
    public class AboutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
